<?php
//ENTER THE RELEVANT INFO BELOW
$mysqlUserName      = "root";
$mysqlPassword      = "";
$mysqlHostName      = "localhost";
$DbName             = "badas_db";
$backup_name        = "mybackup.csv";
$tables             = "badas";

//export.php
$connect = mysqli_connect("localhost", "root", "", "badas_db");
$output = '';

    $query = "SELECT * FROM `badas`";
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0)
    {
        $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                        <th class="th-md">#
                        </th>
                        <th class="th-md">Centre
                        </th>
                        <th class="th-md">District
                        </th>
                        <th class="th-md">Name
                        </th>
                        <th class="th-md">Age
                        </th>
                        <th class="th-md">Gender
                        </th>
                        <th class="th-md">Mobile Number
                        </th>
                        <th class="th-md">Address
                        </th>
                        <th class="th-md">Educational Background
                        </th>
                        <th class="th-md">Occupation
                        </th>
                        <th class="th-lg">Smoking Habit
                        </th>
                        <th class="th-lg">Monthly Family Expense
                        </th>
                        <th class="th-md">Physical Activity
                        </th>
                        <th class="th-lg">How many days do you consume vegetables in a week
                        </th>
                        <th class="th-lg">How many days do you consume fruits in a week
                        </th>
                        <th class="th-lg">Do you have diabetes in your family
                        </th>
                        <th class="th-md"> Marital Status
                        </th>
                        <th class="th-md">Number of child
                        </th>
                        <th class="th-lg">Did you consult with any doc before pregnancy
                        </th>
                        <th class="th-md">Weight
                        </th>
                        <th class="th-md">Height
                        </th>
                        <th class="th-md">BMI
                        </th>
                        <th class="th-md">Waist size
                        </th>
                        <th class="th-md">Blood Pressure
                        </th>
                        <th class="th-md">FBG
                        </th>
                        <th class="th-md">RBG
                        </th>
                        <th class="th-md">Medical
                        </th>
                        <th class="th-md">Insulin Name
                        </th>
                        <th class="th-md">Insulin Doze
                        </th>
                        <th class="th-md">Medicine Name
                        </th>
                        <th class="th-md">Medicine Doze
                        </th>
                        <th class="th-lg">Do you have any pre-knowledge about diabetes
                        </th>
                        <th class="th-lg">What are the risks of diabetes
                        </th>
                        <th class="th-lg">Do you think diabetes can cause different types of physical complication
                        </th>
                        <th class="th-lg">If yes then which complication is connected to diabetes
                        </th>
                        <th class="th-lg">Is diabetes preventive
                        </th>
                        <th class="th-lg">Is there any possibility of having diabetes at the time of pregnancy
                        </th>
                        <th class="th-lg">Proper care before pregnancy reduces the future risk of having diabetes at the time of pregnancy and heart disease
                        </th>
                       
                    </tr>
  ';
        while($row = mysqli_fetch_array($result))
        {
            $output .= '
                    <tr>  
                       <td>'.$row["badas_id"].'</td>  
                       <td>'.$row["center"].'</td>  
                       <td>'.$row["district"].'</td>  
                       <td>'.$row["full_name"].'</td>  
                       <td>'.$row["age"].'</td>
                       <td>'.$row["gender"].'</td>  
                       <td>'.$row["mobile"].'</td>  
                       <td>'.$row["address"].'</td>  
                       <td>'.$row["education"].'</td>  
                       <td>'.$row["occupation"].'</td>
                       <td>'.$row["cigarate"].'</td>  
                       <td>'.$row["monthly_expense"].'</td>  
                       <td>'.$row["physical_exer"].'</td>  
                       <td>'.$row["vegitable"].'</td>  
                       <td>'.$row["fruits"].'</td>
                       <td>'.$row["familyDiab"].'</td>  
                       <td>'.$row["maritial"].'</td>  
                       <td>'.$row["children_count"].'</td>  
                       <td>'.$row["children"].'</td>  
                       <td>'.$row["weight"].'</td>
                       <td>'.$row['heightFeet'].",".$row['heightInch'].'</td>
                       <td>'.$row["bmi"].'</td>  
                       <td>'.$row["wrist"].'</td>  
                       <td>'.$row["blood_pressure"].'</td>  
                       <td>'.$row["sugarLevelEmpty"].'</td>  
                       <td>'.$row["sugarLevelFill"].'</td>
                       <td>'.$row["medical"].'</td>
                       <td>'.$row["insulinName"].'</td>  
                       <td>'.$row["insulinDoze"].'</td>  
                       <td>'.$row["medicineName"].'</td>
                       <td>'.$row["medicineDoze"].'</td>  
                       <td>'.$row["one"].'</td>  
                       <td>'.$row["two"].'</td>  
                       <td>'.$row["three"].'</td>  
                       <td>'.$row["four"].'</td>                       
                       <td>'.$row["five"].'</td>  
                       <td>'.$row["six"].'</td>
                       <td>'.$row["seven"].'</td>
                    </tr>
   ';
        }
        $output .= '</table>';
        header('Content-Type: application/xlsx');
        header('Content-Disposition: attachment; filename=download.xlsx');
        echo $output;

}
?>