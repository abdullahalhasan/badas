<?php
    include('db_connect.php');
    //error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>BADAS</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link href="style.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head><!--/head-->
    <body>
    <br>
    <br>
    <form method='post' action='database.php' onclick='myFunction'>
<?php
    // REGISTER USER
    if (isset($_POST['submit_btn'])) {
        // receive all input values from the form

        $center = $_POST['center'];
        $district = $_POST['district'];
        $name = $_POST['name'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $mobile = $_POST['mobile'];
        $address = $_POST['address'];
        $education = $_POST['education'];
        $occupation = $_POST['occupation'];
        $cigarate = $_POST['cigarate'];
        $monthly_expense = $_POST['monthly_expense'];
        $physical_exer = $_POST['physical_exer'];
        $vegitable = $_POST['vegitable'];
        $fruits = $_POST['fruits'];
        $familyDiab = $_POST['familyDiab'];
        $maritial = $_POST['maritial'];
        $children_count = $_POST['children_count'];
        $children = $_POST['children'];
        $weight = $_POST['weight'];
        $heightFeet = $_POST['heightFeet'];
        $heightFeet = $heightFeet*12;
        $heightInch = $_POST['heightInch'];
        $heightInch = (($heightFeet+$heightInch)*2.54);
        $bmi = $weight/(((($heightFeet*12)+$heightInch)*0.0254)*(($heightFeet*12)+$heightInch)*0.0254);
        $wrist = $_POST['wrist'];
        $wrist = $wrist*2.54;
        $blood_pressure_sys = $_POST['blood_pressure_sys'];
        $blood_pressure_dys = $_POST['blood_pressure_dys'];
        $blood_pressure = $blood_pressure_sys."/".$blood_pressure_dys;
        if ($blood_pressure_sys<=120 && $blood_pressure_dys<=80) {
            $blood_remark = "Normal";
        } else {
            $blood_remark = "High BP";
        }

        $sugarLevelEmpty = $_POST['sugarLevelEmpty'];

        if ($sugarLevelEmpty<6.1) {
            $sle_remarks = "Normal";
        } else if($sugarLevelEmpty>=6.1 && $sugarLevelEmpty<=6.9) {
            $sle_remarks= "Pre-Diabetes";
        } else if($sugarLevelEmpty>=7){
            $sle_remarks= "Diabetes";
        }

        $sugarLevelFill = $_POST['sugarLevelFill'];

        if ($sugarLevelFill<7.8) {
            $slf_remarks = "Normal";
        } else if($sugarLevelFill>=7. && $sugarLevelEmpty<=11.0) {
            $slf_remarks= "Pre-Diabetes";
        } else if($sugarLevelFill>=11.1){
            $slf_remarks= "Diabetes";
        }

        $medical = $_POST['medical'];
        $insulinName = $_POST['insulinName'];
        $insulinDoze = $_POST['insulinDoze'];
        $medicineName = $_POST['medicineName'];
        $medicineDoze = $_POST['medicineDoze'];

        $one = $_POST['001'];
        $two = implode($_POST['002']);
        $three = $_POST['003'];
        $four = implode($_POST['004']);
        $five = $_POST['005'];
        $six = $_POST['006'];
        $seven = $_POST['007'];
        /*echo $bmi;
        die;*/

        $query = "INSERT INTO badas (badas_id, center, district, 
                  full_name, age, gender, 
                  mobile, address, education, 
                  occupation,cigarate, monthly_expense, 
                  physical_exer, vegitable, fruits, 
                  familyDiab, maritial, children_count, 
                  children, weight, heightFeet, 
                  heightInch,bmi, wrist, 
                  blood_pressure, blood_remark, 
                  sugarLevelEmpty, sle_remarks, 
                  sugarLevelFill, slf_remarks , 
                  medical,
                  insulinName,insulinDoze,
                  medicineName,medicineDoze, 
                  one, two, three, four, five, six, seven) 
                  VALUES(null, '$center','$district',
                  '$name','$age','$gender', 
                  '$mobile','$address','$education',
                  '$occupation','$cigarate', '$monthly_expense', 
                  '$physical_exer','$vegitable','$fruits',
                  '$familyDiab', '$maritial', '$children_count',
                  '$children','$weight','$heightFeet', 
                  '$heightInch','$bmi','$wrist',
                  '$blood_pressure','$blood_remark',
                  '$sugarLevelEmpty','$sle_remarks',
                  '$sugarLevelFill','$slf_remarks',
                  '$medical',
                  '$insulinName','$insulinDoze',
                  '$medicineName','$medicineDoze',
                  '$one','$two','$three','$four','$five', '$six', '$seven')";

//        echo $query;
//        die;
        $database ="badas_db";
        $ifInsert = mysqli_query($db,$query);

        if ($ifInsert) {
            echo    "
                        <div class='container'>
                            <div class='jumbotron' >
                                <h1 class='txt-md-center'>আপনার দেয়া তথ্য ডাটাবেজে সফল ভাবে জমা হয়েছে। আরেকটি এন্ট্রি করুন।</h1>
                                
                            </div>
                            <div style='float: right'>
                                 <a href='index.php'> <input type='button' class='btn btn-success' name='abs' value='নতুন এন্ট্রি করুন'> </a>
                            </div>
                        </div>
                    ";


        } else {

            echo "<div class='container'>
                            <div class='jumbotron' >
                                <h1 class='txt-md-center'>আপনার ডাটা এন্ট্রি সফল হয় নি। অনুগ্রহ করে আবার এন্ট্রি করুন।</h1>
                                
                            </div>
                            <div style='float: right'>
                                 <a href='index.php'> <input type='button' class='btn btn-success' name='abs' value='আবার জমা দিন'> </a>
                            </div>
                        </div>";



        }


    }

?>
    </form>
    </body>
</html>
